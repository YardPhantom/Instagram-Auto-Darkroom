from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.json"
SESSION_PATH = ROOT / "session.json"
LOG_PATH = ROOT / "logs" / "posts.json"
DEFAULTS: dict[str, Any] = {
    "watch_folder": r"C:\projects\InstagramAuto",
    "done_folder": r"C:\projects\InstagramAuto\done",
    "instagram_username": "",
    "instagram_password": "",
    "interval_minutes": 240,
    "quiet_hours": True,
    "quiet_start": "23:00",
    "quiet_end": "07:30",
    "videos_as_reels": True,
    "also_first_comment": False,
    "skip_without_caption": True,
    "auto_post": False,
}


def load_config() -> dict[str, Any]:
    data = dict(DEFAULTS)
    if CONFIG_PATH.exists():
        try:
            data.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            pass
    return data


def save_config(data: dict[str, Any]) -> dict[str, Any]:
    merged = load_config()
    merged.update({k: v for k, v in data.items() if k in DEFAULTS or k.endswith("_password") or k.endswith("_username")})
    CONFIG_PATH.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    return merged


def public_config(data: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = dict(data or load_config())
    cfg["has_password"] = bool(cfg.get("instagram_password"))
    cfg.pop("instagram_password", None)
    return cfg
