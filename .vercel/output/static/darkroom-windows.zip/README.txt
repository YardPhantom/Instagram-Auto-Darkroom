DARKROOM for IIS 10
===================

Extract this folder to C:\projects\Darkroom (keep it out of the media inbox).

1. Install Python 3.11+ and the IIS HttpPlatformHandler module.
2. Run setup.ps1
3. In IIS Manager, add a site whose physical path is this folder.
4. Put photos/videos in C:\projects\InstagramAuto with a matching
   annotation file (same name, .txt / .caption / .json).
5. Open the site, save the Instagram session, press Start.

After a successful post, the media file and its annotation move to
C:\projects\InstagramAuto\done.

JSON annotation example:

  { "caption": "Salt air.", "comment": "Shot on 35." }

Without IIS you can run run.bat and open http://127.0.0.1:8080
